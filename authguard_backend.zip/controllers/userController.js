const User = require('../model/User');


//get All Users
const users_all = async (req,res) => {
    try{
        const users = await User.find();
        res.json(users);
    } catch(error){
        res.json({message: error})
    }
};
//get Single User 
const user_details = async (req,res) => {

};
//Add new User
const user_create = async (req,res) => {

};
//Update user
const user_update = async (req,res) => {

};
//delete user
const user_delete = async (req,res) => {

};


module.exports = {
    users_all,
    user_details,
    user_create,
    user_update,
    user_delete
}