const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    firstName:String,
    lastName:String,
    city:String
});

module.exports = mongoose.model('Users', userSchema)