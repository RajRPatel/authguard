const express = require('express')

const app = express();
const dotenv = require('dotenv');
const mongoose = require('mongoose');
 
dotenv.config()

//to connect to db
mongoose.connect(
    process.env.DB_CONNECT,
    {useUnifiedTopology:true, useNewUrlParser:true},
    ()=> console.log('connected to db')
);

//Import Routes
const userRoutes = require('./routes/user');
//route middleware
app.use('api/user',userRoutes);

app.listen(4000, ()=> console.log('server is running on 4000 port'));
