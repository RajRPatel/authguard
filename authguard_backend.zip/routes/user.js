const router = require('express').Router();
const userController = require('../controllers/userController');
router.post('/');
router.get('/', userController.users_all);
router.get('/:userId');
router.put('/:userId');
router.delete('/:userId');

module.exports = router