import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
export interface User {
  firstName: any;
  lastName: any;
  city: any;
}
@Component({
  selector: 'app-loggedin',
  templateUrl: './loggedin.component.html',
  styleUrls: ['./loggedin.component.scss']
})
export class LoggedinComponent implements OnInit {
  addUser: FormGroup | any;
  userObj: User[] = [];
  isSave: boolean = false;
  editIndex!: number;
  constructor() {
    this.createForm()
  }

  createForm() {
    this.addUser = new FormGroup({
      firstName: new FormControl('', [Validators.required]),
      lastName: new FormControl('', [Validators.required]),
      city: new FormControl('', [Validators.required])
    });
  }

  ngOnInit(): void {
  }
  addUpdateDelFunc(task: string, index: number = 0) {
    let obj: any = {
      firstName: this.addUser.value.firstName,
      lastName: this.addUser.value.lastName,
      city: this.addUser.value.city
    }
    switch (task) {
      case 'add':
        this.userObj.push(obj)
        this.addUser.reset();
        break;
      case 'del':
        this.userObj.splice(index, 1)
        break;
      case 'edit':
        this.editIndex = index;
        this.addUser.setValue(this.userObj[index]);
        this.isSave = true;
        break;
      case 'save':
        this.userObj[this.editIndex] = obj;
        this.addUser.reset()
        this.isSave = false;
        break;
      default:
        break;
    }
  }
}
