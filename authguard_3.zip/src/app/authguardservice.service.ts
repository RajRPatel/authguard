import { Injectable } from '@angular/core';
const pwd = 'RajRPatel@03';
@Injectable({
  providedIn: 'root'
})
export class AuthguardserviceService {
  
  constructor() { }
  gettoken() {
    const getpwd = localStorage.getItem("user");
    if (pwd !== getpwd) {
      console.log('fromData', getpwd);
      return false
    } else {
      console.log('true')
      return true;
    }
  }
}
